import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;


public class CancelTicket extends JFrame {

    public CancelTicket() {

        setTitle("Cancel Ticket");
        setSize(550, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(250, 240, 240));

        JLabel title = new JLabel(" Cancel Reservation");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBounds(170, 30, 300, 30);
        add(title);

        JLabel lbl = new JLabel("Are you sure you want to cancel your ticket?");
        lbl.setFont(new Font("Arial", Font.PLAIN, 15));
        lbl.setBounds(110, 90, 400, 25);
        add(lbl);

        JButton btnYes = new JButton("Yes, Cancel");
        btnYes.setBounds(120, 150, 140, 40);
        btnYes.setBackground(new Color(200, 60, 60));
        btnYes.setForeground(Color.WHITE);
        add(btnYes);

        JButton btnNo = new JButton("No");
        btnNo.setBounds(300, 150, 100, 40);
        btnNo.setBackground(Color.GRAY);
        btnNo.setForeground(Color.WHITE);
        add(btnNo);

        btnYes.addActionListener(e -> {
            JOptionPane.showMessageDialog(this,
                    "Ticket Cancelled Successfully");
            dispose();
            new WelcomePage().setVisible(true);
        });

        btnNo.addActionListener(e -> {
            dispose();
            new Ticket().setVisible(true);
        });
    }

    public static void main(String[] args) {
        new CancelTicket().setVisible(true);
    }
}