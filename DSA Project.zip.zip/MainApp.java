import javax.swing.SwingUtilities;
import java.util.List;
import java.util.ArrayList;



public class MainApp {

    public static void main(String[] args) {
        // Run GUI safely
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new WelcomePage();
            }
        });
    }
}
