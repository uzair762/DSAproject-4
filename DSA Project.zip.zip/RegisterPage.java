import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;



import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RegisterPage extends JFrame {

    JTextField nameField, userField;
    JPasswordField passField;

    public RegisterPage() {
        setTitle("Register - Flight Reservation System");
        setSize(800, 480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(0, 153, 76),
                        0, getHeight(), new Color(0, 204, 153));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(null);

        JLabel title = new JLabel("USER REGISTRATION");
        title.setBounds(250, 40, 400, 40);
        title.setFont(new Font("Arial", Font.BOLD, 32));
        title.setForeground(Color.WHITE);
        panel.add(title);

        JLabel nameLbl = new JLabel("Full Name:");
        nameLbl.setBounds(220, 130, 120, 30);
        nameLbl.setFont(new Font("Arial", Font.BOLD, 16));
        nameLbl.setForeground(Color.WHITE);
        panel.add(nameLbl);

        nameField = new JTextField();
        nameField.setBounds(360, 130, 200, 30);
        panel.add(nameField);

        JLabel userLbl = new JLabel("Username:");
        userLbl.setBounds(220, 180, 120, 30);
        userLbl.setFont(new Font("Arial", Font.BOLD, 16));
        userLbl.setForeground(Color.WHITE);
        panel.add(userLbl);

        userField = new JTextField();
        userField.setBounds(360, 180, 200, 30);
        panel.add(userField);

        JLabel passLbl = new JLabel("Password:");
        passLbl.setBounds(220, 230, 120, 30);
        passLbl.setFont(new Font("Arial", Font.BOLD, 16));
        passLbl.setForeground(Color.WHITE);
        panel.add(passLbl);

        passField = new JPasswordField();
        passField.setBounds(360, 230, 200, 30);
        panel.add(passField);

        JButton registerBtn = createButton("REGISTER");
        registerBtn.setBounds(270, 310, 130, 40);
        panel.add(registerBtn);

        JButton backBtn = createButton("BACK");
        backBtn.setBounds(430, 310, 130, 40);
        panel.add(backBtn);

        // REGISTER ACTION
        registerBtn.addActionListener(e -> registerUser());

        // BACK ACTION
        backBtn.addActionListener(e -> {
            dispose();
            new WelcomePage();
        });

        add(panel);
        setVisible(true);
    }

    private void registerUser() {
      String fullName = nameField.getText().trim();
String username = userField.getText().trim();
String password = new String(passField.getPassword()).trim();

if (fullName.isEmpty() || username.isEmpty() || password.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
} else {
    try {
        FileWriter fw = new FileWriter("users.txt", true); // true for append mode
        fw.write(fullName + "," + username + "," + password + "\n");
        fw.close();

        UserData.users.add(new String[]{fullName, username, password});
JOptionPane.showMessageDialog(this, "User registered successfully!");
        dispose();
        new LoginPage(); // Go to login page after successful registration
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error saving user data");
    }
        }
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setBackground(Color.WHITE);
        btn.setForeground(Color.BLACK);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(Color.BLACK);
                btn.setForeground(Color.WHITE);
            }

            public void mouseExited(MouseEvent e) {
                btn.setBackground(Color.WHITE);
                btn.setForeground(Color.BLACK);
            }
        });
        return btn;
    }
}
