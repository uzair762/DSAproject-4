import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;


public class FlightData {

    public static ArrayList<Flight> flights = new ArrayList<>();

    // Static block runs once
    static {
        flights.add(new Flight("PK101", "Pakistan", "UAE",
                "12-02-2026", "10:00 AM", "Economy", 60, 45000));

        flights.add(new Flight("PK102", "Pakistan", "UAE",
                "12-02-2026", "06:00 PM", "Business", 20, 95000));

        flights.add(new Flight("PK201", "Pakistan", "UK",
                "15-02-2026", "02:00 PM", "Economy", 70, 120000));

        flights.add(new Flight("PK202", "Pakistan", "UK",
                "15-02-2026", "09:00 PM", "Business", 25, 220000));

        flights.add(new Flight("PK301", "Pakistan", "Turkey",
                "18-02-2026", "11:30 AM", "Economy", 80, 90000));

        flights.add(new Flight("PK302", "Pakistan", "Turkey",
                "18-02-2026", "08:45 PM", "Business", 30, 160000));
    }

    // SEARCH FLIGHTS
    public static ArrayList<Flight> searchFlights(
            String from, String to, String travelClass) {

        ArrayList<Flight> result = new ArrayList<>();

        for (Flight f : flights) {
            if (f.getFromCountry().equalsIgnoreCase(from)
                    && f.getToCountry().equalsIgnoreCase(to)
                    && f.getTravelClass().equalsIgnoreCase(travelClass)) {
                result.add(f);
            }
        }
        return result;
    }
}

