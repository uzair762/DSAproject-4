import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JOptionPane;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;


public class LoginPage extends JFrame {

    JTextField userField;
    JPasswordField passField;

    public LoginPage() {
        setTitle("Login - Flight Reservation System");
        setSize(800, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(102, 0, 153),
                        0, getHeight(), new Color(0, 153, 204));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(null);

        JLabel title = new JLabel("USER LOGIN");
        title.setBounds(310, 40, 300, 40);
        title.setFont(new Font("Arial", Font.BOLD, 32));
        title.setForeground(Color.WHITE);
        panel.add(title);

        JLabel userLbl = new JLabel("Username:");
        userLbl.setBounds(220, 130, 120, 30);
        userLbl.setFont(new Font("Arial", Font.BOLD, 16));
        userLbl.setForeground(Color.WHITE);
        panel.add(userLbl);

        userField = new JTextField();
        userField.setBounds(350, 130, 200, 30);
        panel.add(userField);

        JLabel passLbl = new JLabel("Password:");
        passLbl.setBounds(220, 180, 120, 30);
        passLbl.setFont(new Font("Arial", Font.BOLD, 16));
        passLbl.setForeground(Color.WHITE);
        panel.add(passLbl);

        passField = new JPasswordField();
        passField.setBounds(350, 180, 200, 30);
        panel.add(passField);

        JButton loginBtn = createButton("LOGIN");
        loginBtn.setBounds(260, 250, 130, 40);
        panel.add(loginBtn);

        JButton backBtn = createButton("BACK");
        backBtn.setBounds(410, 250, 130, 40);
        panel.add(backBtn);

        // LOGIN ACTION
        loginBtn.addActionListener(e -> login());

        // BACK ACTION
        backBtn.addActionListener(e -> {
            dispose();
            new WelcomePage();
        });

        add(panel);
        setVisible(true);
    }

    private void login() {
        String username = userField.getText().trim();
String password = new String(passField.getPassword()).trim();
boolean found = false;
for(String[] user : UserData.users){
    if(user[1].equals(username) && user[2].equals(password)){
        found = true;
        break;
    }
}

try {
    BufferedReader br = new BufferedReader(new FileReader("users.txt"));
    String line;
    while ((line = br.readLine()) != null) {
        String[] data = line.split(","); // Splits the line by comma
        // data[0] = name, data[1] = username, data[2] = password
        if (data.length == 3 && data[1].equals(username) && data[2].equals(password)) {
            found = true;
            break;
        }
    }
    br.close();
} catch (IOException e) {
    JOptionPane.showMessageDialog(this, "Error reading user file", "Error", JOptionPane.ERROR_MESSAGE);
}

if (found) {
    JOptionPane.showMessageDialog(this, "Login Successful!");
    this.dispose();
    SwingUtilities.invokeLater(() -> {
            new FlightSchedule().setVisible(true);
        }); // This will open your next screen
} else {
    JOptionPane.showMessageDialog(this, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
}
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        btn.setBackground(Color.WHITE);
        btn.setForeground(Color.BLACK);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(Color.BLACK);
                btn.setForeground(Color.WHITE);
            }

            public void mouseExited(MouseEvent e) {
                btn.setBackground(Color.WHITE);
                btn.setForeground(Color.BLACK);
            }
        });
        return btn;
    }
}
