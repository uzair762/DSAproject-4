import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;


public class WelcomePage extends JFrame {

    public WelcomePage() {
        setTitle("Flight Reservation System");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Main Panel
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(0, 102, 204),
                        0, getHeight(), new Color(0, 204, 204));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(null);

        // Title
        JLabel title = new JLabel("FLIGHT RESERVATION SYSTEM");
        title.setBounds(170, 50, 600, 60);
        title.setFont(new Font("Arial", Font.BOLD, 36));
        title.setForeground(Color.WHITE);
        mainPanel.add(title);

        // Subtitle
        JLabel subtitle = new JLabel("Welcome to Airline Booking Portal");
        subtitle.setBounds(280, 110, 400, 30);
        subtitle.setFont(new Font("Arial", Font.PLAIN, 18));
        subtitle.setForeground(Color.WHITE);
        mainPanel.add(subtitle);

        // Buttons
        JButton loginBtn = createButton("LOGIN");
        loginBtn.setBounds(350, 180, 200, 45);
        mainPanel.add(loginBtn);

        JButton registerBtn = createButton("REGISTER");
        registerBtn.setBounds(350, 240, 200, 45);
        mainPanel.add(registerBtn);

        JButton exitBtn = createButton("EXIT");
        exitBtn.setBounds(350, 300, 200, 45);
        mainPanel.add(exitBtn);

        // Button Actions
        loginBtn.addActionListener(e -> {
            dispose();
            new LoginPage();
        });

        registerBtn.addActionListener(e -> {
            dispose();
            new RegisterPage();
        });

        exitBtn.addActionListener(e -> System.exit(0));

        add(mainPanel);
        setVisible(true);
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 16));
        btn.setFocusPainted(false);
        btn.setBackground(Color.WHITE);
        btn.setForeground(new Color(0, 102, 204));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(0, 102, 204));
                btn.setForeground(Color.WHITE);
            }

            public void mouseExited(MouseEvent e) {
                btn.setBackground(Color.WHITE);
                btn.setForeground(new Color(0, 102, 204));
            }
        });
        return btn;
    }
}
