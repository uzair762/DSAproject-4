import java.util.List;

public class BookingInfo {
    public String fullName;
    public String cnic;
    public String gender;
    public String flightClass;
    public String from;
    public String to;
    public String flightNo;
    public List<String> seats;
}
