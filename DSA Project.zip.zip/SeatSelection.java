import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;

public class SeatSelection extends JFrame {

    JButton[] seats = new JButton[30];
    boolean[] booked = new boolean[30];

    JLabel lblInfo;

    public SeatSelection() {

        setTitle("Seat Selection");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(245, 250, 255));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // ===== TITLE =====
        JLabel title = new JLabel(" Select Your Seat");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(new Color(0, 80, 150));
        title.setBounds(240, 10, 300, 30);
        add(title);

        // ===== INFO =====
        lblInfo = new JLabel("Click seat to select (Green = Available)");
        lblInfo.setFont(new Font("Arial", Font.BOLD, 14));
        lblInfo.setBounds(30, 50, 400, 25);
        add(lblInfo);

        // ===== SEAT PANEL =====
        JPanel seatPanel = new JPanel();
        seatPanel.setLayout(new GridLayout(5, 6, 10, 10));
        seatPanel.setBounds(50, 90, 580, 260);
        seatPanel.setBackground(new Color(245, 250, 255));
        add(seatPanel);

        // ===== CREATE SEATS =====
        for (int i = 0; i < 30; i++) {
            seats[i] = new JButton("S" + (i + 1));
            seats[i].setBackground(Color.GREEN);
            seats[i].setFocusPainted(false);
            seatPanel.add(seats[i]);

            int index = i;

            seats[i].addActionListener(e -> {
                if (booked[index]) {
                    JOptionPane.showMessageDialog(this,
                            "Seat already booked!");
                } else {
                    seats[index].setBackground(Color.YELLOW);
                    lblInfo.setText("Selected Seat: S" + (index + 1));
                }
            });
        }

        // ===== CONFIRM BUTTON =====
        JButton btnConfirm = new JButton("Confirm Booking");
        btnConfirm.setBounds(150, 380, 180, 40);
        btnConfirm.setBackground(new Color(0, 150, 90));
        btnConfirm.setForeground(Color.WHITE);
        add(btnConfirm);

        // ===== CANCEL BUTTON =====
        JButton btnCancel = new JButton("Cancel");
        btnCancel.setBounds(370, 380, 120, 40);
        btnCancel.setBackground(new Color(200, 60, 60));
        btnCancel.setForeground(Color.WHITE);
        add(btnCancel);

        // ===== CONFIRM LOGIC =====
        btnConfirm.addActionListener(e -> {
    boolean selected = false;
List<String> selectedSeats = new ArrayList<>();
    for (int i = 0; i < seats.length; i++) {
        if (seats[i].getBackground() == Color.YELLOW) {
            seats[i].setBackground(Color.RED);
            booked[i] = true;
            selected = true;
            selectedSeats.add("S" + (i+1));

        }
    }
    BookingInfo info = new BookingInfo();
info.seats = selectedSeats;
info.from = "Pakistan"; // example
info.to = "UAE";
info.flightNo = "PK101";

    if (!selected) {
        JOptionPane.showMessageDialog(this, "Please select at least one seat");
    } else {
        JOptionPane.showMessageDialog(this, "Seat booked successfully. Proceeding to booking...");

        // 🔹 Close SeatMap
        this.dispose();

        // 🔹 Open BookingPage (next step)
        SwingUtilities.invokeLater(() -> new BookingPage(info).setVisible(true));
    }
});


    }

    // ===== MAIN =====
    public static void main(String[] args) {
        new SeatSelection().setVisible(true);
    }
}

