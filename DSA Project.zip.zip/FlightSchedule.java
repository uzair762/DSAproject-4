import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;


public class FlightSchedule extends JFrame {

    JComboBox<String> cbFrom, cbTo, cbClass;
    JTable table;
    DefaultTableModel model;
    JLabel lblSeats;

    public FlightSchedule() {

        setTitle("Flight Reservation System");
        setSize(900, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(230, 245, 255));
        setLayout(null);

        // ===== TITLE =====
        JLabel title = new JLabel(" Flight Schedule");
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(new Color(0, 70, 140));
        title.setBounds(320, 10, 300, 40);
        add(title);

        // ===== FROM =====
        JLabel lblFrom = new JLabel("From:");
        lblFrom.setBounds(40, 70, 80, 25);
        add(lblFrom);

        cbFrom = new JComboBox<>(new String[]{
                "Pakistan", "UAE", "USA", "UK", "Turkey", "Saudi Arabia"
        });
        cbFrom.setBounds(120, 70, 150, 25);
        add(cbFrom);

        // ===== TO =====
        JLabel lblTo = new JLabel("To:");
        lblTo.setBounds(300, 70, 80, 25);
        add(lblTo);

        cbTo = new JComboBox<>(new String[]{
                "Pakistan", "UAE", "USA", "UK", "Turkey", "Saudi Arabia"
        });
        cbTo.setBounds(360, 70, 150, 25);
        add(cbTo);

        // ===== CLASS =====
        JLabel lblClass = new JLabel("Class:");
        lblClass.setBounds(540, 70, 80, 25);
        add(lblClass);

        cbClass = new JComboBox<>(new String[]{"Economy", "Business"});
        cbClass.setBounds(600, 70, 150, 25);
        add(cbClass);

        // ===== SEARCH BUTTON =====
        JButton btnSearch = new JButton("Search Flights");
        btnSearch.setBounds(350, 110, 180, 35);
        btnSearch.setBackground(new Color(0, 120, 215));
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFocusPainted(false);
        add(btnSearch);

        // ===== TABLE =====
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{
                "Flight No", "From", "To", "Class", "Seats Available", "Price"
        });

        table = new JTable(model);
        table.setRowHeight(25);

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(40, 170, 800, 250);
        add(sp);

        // ===== SEATS LABEL =====
        lblSeats = new JLabel("Select a flight to see seat details");
        lblSeats.setFont(new Font("Arial", Font.BOLD, 14));
        lblSeats.setForeground(new Color(0, 100, 0));
        lblSeats.setBounds(40, 430, 400, 25);
        add(lblSeats);

        // ===== BOOK BUTTON =====
        JButton btnBook = new JButton("Book Ticket");
        btnBook.setBounds(600, 430, 150, 35);
        btnBook.setBackground(new Color(0, 170, 90));
        btnBook.setForeground(Color.WHITE);
        add(btnBook);

        // ===== SEARCH LOGIC =====
        btnSearch.addActionListener(e -> {
            model.setRowCount(0); // clear table

            String from = cbFrom.getSelectedItem().toString();
            String to = cbTo.getSelectedItem().toString();
            String cls = cbClass.getSelectedItem().toString();

            if (from.equals(to)) {
                JOptionPane.showMessageDialog(this,
                        "From and To cannot be same!");
                return;
            }

            // Dummy flights (DSA arrays)
            model.addRow(new Object[]{"PK101", from, to, cls, 25, "45,000 PKR"});
            model.addRow(new Object[]{"PK205", from, to, cls, 18, "52,000 PKR"});
            model.addRow(new Object[]{"PK330", from, to, cls, 10, "60,000 PKR"});
        });

        // ===== TABLE CLICK =====
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                String flight = model.getValueAt(row, 0).toString();
                String seats = model.getValueAt(row, 4).toString();
                lblSeats.setText("Flight " + flight +
                        " has " + seats + " seats remaining");
            }
        });

        // ===== BOOK BUTTON LOGIC =====
        btnBook.addActionListener(e -> {
            int row = table.getSelectedRow();

            if (row == -1) {
                JOptionPane.showMessageDialog(this,
                        "Please select a flight first");
                return;
            }
this.dispose();

    // 2️⃣ Open Seat Selection screen
    SwingUtilities.invokeLater(() -> {
        new SeatSelection().setVisible(true); // ya SeatSelection.java
    });
            JOptionPane.showMessageDialog(this,
                    "Ticket Booked Successfully!\nProceeding to Seat Selection...");
            // NEXT SCREEN later (SeatSelection.java)
        });
    }

    // ===== MAIN =====
    public static void main(String[] args) {
        new FlightSchedule().setVisible(true);
    }
}
