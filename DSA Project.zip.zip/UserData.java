
import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;


public class UserData {
    public static ArrayList<String[]> users = new ArrayList<>();
    // Each user stored as {fullName, username, password}
}
