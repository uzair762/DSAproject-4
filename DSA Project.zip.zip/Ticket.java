import javax.swing.*;
import java.awt.*;
import static java.awt.SystemColor.info;
import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;


public class Ticket extends JFrame {

    public Ticket() {

        setTitle("Ticket Generated");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(245, 250, 255));

        JLabel title = new JLabel(" Ticket Generated Successfully");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBounds(130, 40, 400, 30);
        add(title);

        JButton btnView = new JButton("View Ticket");
        btnView.setBounds(200, 120, 200, 40);
        btnView.setBackground(new Color(0, 140, 200));
        btnView.setForeground(Color.WHITE);
        add(btnView);

        JButton btnCancel = new JButton("Cancel Ticket");
        btnCancel.setBounds(200, 180, 200, 40);
        btnCancel.setBackground(new Color(200, 70, 70));
        btnCancel.setForeground(Color.WHITE);
        add(btnCancel);

        JButton btnExit = new JButton("Exit");
        btnExit.setBounds(200, 240, 200, 40);
        btnExit.setBackground(Color.GRAY);
        btnExit.setForeground(Color.WHITE);
        add(btnExit);

        // LOGIC
        btnView.addActionListener(e -> {
            dispose();
            new TicketView(info).setVisible(true);
        });

        btnCancel.addActionListener(e -> {
            dispose();
            new CancelTicket().setVisible(true);
        });

        btnExit.addActionListener(e -> System.exit(0));
    }

    public static void main(String[] args) {
        new Ticket(info).setVisible(true);
    }

    private Ticket(SystemColor info) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
