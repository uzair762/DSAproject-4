import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;
import java.util.*;

public class BookingPage extends JFrame {

    JTextField txtName, txtCNIC;
    JComboBox<String> cbGender, cbClass;
private BookingInfo info;

    public BookingPage(BookingInfo info){
    this.info = info;

        setTitle("Booking Details");
        setSize(650, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(240, 248, 255));

        // ===== TITLE =====
        JLabel title = new JLabel("Booking Details");
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(new Color(0, 80, 150));
        title.setBounds(210, 15, 300, 40);
        add(title);

        // ===== NAME =====
        JLabel lblName = new JLabel("Passenger Name:");
        lblName.setBounds(120, 90, 150, 25);
        lblName.setFont(new Font("Arial", Font.BOLD, 14));
        add(lblName);

        txtName = new JTextField();
        txtName.setBounds(280, 90, 200, 28);
        add(txtName);

        // ===== CNIC =====
        JLabel lblCNIC = new JLabel("CNIC:");
        lblCNIC.setBounds(120, 140, 150, 25);
        lblCNIC.setFont(new Font("Arial", Font.BOLD, 14));
        add(lblCNIC);

        txtCNIC = new JTextField();
        txtCNIC.setBounds(280, 140, 200, 28);
        add(txtCNIC);

        // ===== GENDER =====
        JLabel lblGender = new JLabel("Gender:");
        lblGender.setBounds(120, 190, 150, 25);
        lblGender.setFont(new Font("Arial", Font.BOLD, 14));
        add(lblGender);

        cbGender = new JComboBox<>(new String[]{"Male", "Female"});
        cbGender.setBounds(280, 190, 200, 28);
        add(cbGender);

        // ===== CLASS =====
        JLabel lblClass = new JLabel("Class:");
        lblClass.setBounds(120, 240, 150, 25);
        lblClass.setFont(new Font("Arial", Font.BOLD, 14));
        add(lblClass);

        cbClass = new JComboBox<>(new String[]{"Economy", "Business"});
        cbClass.setBounds(280, 240, 200, 28);
        add(cbClass);

        // ===== CONFIRM BUTTON =====
        JButton btnConfirm = new JButton("Confirm Booking");
        btnConfirm.setBounds(200, 320, 200, 40);
        btnConfirm.setBackground(new Color(0, 150, 90));
        btnConfirm.setForeground(Color.WHITE);
        btnConfirm.setFont(new Font("Arial", Font.BOLD, 15));
        add(btnConfirm);

        // ===== BACK BUTTON =====
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(430, 400, 120, 35);
        btnBack.setBackground(new Color(200, 70, 70));
        btnBack.setForeground(Color.WHITE);
        add(btnBack);

        // ===== CONFIRM LOGIC =====
        btnConfirm.addActionListener(e -> {
            info.fullName = txtName.getText();
        info.cnic = txtCNIC.getText();
        info.gender = cbGender.getSelectedItem().toString();
        info.flightClass = cbClass.getSelectedItem().toString();

            if (txtName.getText().isEmpty() ||
                txtCNIC.getText().isEmpty()) {

                JOptionPane.showMessageDialog(this,
                        "Please fill all fields");
                return;
            }

            JOptionPane.showMessageDialog(this,
                    "Booking Confirmed!");

            this.dispose();
        SwingUtilities.invokeLater(() -> new TicketView(info).setVisible(true));
    });


        // ===== BACK LOGIC =====
        btnBack.addActionListener(e -> {
            dispose();
            new SeatSelection().setVisible(true);
        });
    }

    // ===== MAIN (TEST) =====
    public static void main(String[] args) {
        new BookingPage().setVisible(true);
    }

    private BookingPage() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
