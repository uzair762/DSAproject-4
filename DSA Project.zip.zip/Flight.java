import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;


public class Flight {

    private String flightId;
    private String fromCountry;
    private String toCountry;
    private String date;
    private String time;
    private String travelClass; // Economy / Business
    private int totalSeats;
    private int availableSeats;
    private double price;

    public Flight(String flightId, String fromCountry, String toCountry,
                  String date, String time, String travelClass,
                  int totalSeats, double price) {

        this.flightId = flightId;
        this.fromCountry = fromCountry;
        this.toCountry = toCountry;
        this.date = date;
        this.time = time;
        this.travelClass = travelClass;
        this.totalSeats = totalSeats;
        this.availableSeats = totalSeats;
        this.price = price;
    }

    // GETTERS
    public String getFlightId() {
        return flightId;
    }

    public String getFromCountry() {
        return fromCountry;
    }

    public String getToCountry() {
        return toCountry;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getTravelClass() {
        return travelClass;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public double getPrice() {
        return price;
    }

    // BOOK SEATS
    public boolean bookSeats(int seats) {
        if (seats <= availableSeats) {
            availableSeats -= seats;
            return true;
        }
        return false;
    }

    // CANCEL SEATS
    public void cancelSeats(int seats) {
        availableSeats += seats;
        if (availableSeats > totalSeats) {
            availableSeats = totalSeats;
        }
    }
}


