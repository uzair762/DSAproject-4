import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import javax.swing.SwingUtilities;


public class TicketView extends JFrame {

    private BookingInfo info;
    
    public TicketView(BookingInfo info){
    this.info = info;
        setTitle("Ticket Details");
        setSize(600, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(235, 245, 255));

        JLabel title = new JLabel(" Flight Ticket");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setBounds(220, 20, 300, 30);
        add(title);

        JTextArea ticketArea = new JTextArea();
        ticketArea.setBounds(100, 80, 400, 220);
        ticketArea.setEditable(false);
        ticketArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        ticketArea.setText("Passenger Name : " + info.fullName + "\n" +
        "CNIC           : " + info.cnic + "\n" +
        "From            : " + info.from + "\n" +
        "To              : " + info.to + "\n" +
        "Class           : " + info.flightClass + "\n" +
        "Seat No         : " + String.join(", ", info.seats) + "\n" +
        "Flight No       : " + info.flightNo + "\n" +
        "Status          : CONFIRMED"
        );
        add(ticketArea);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(240, 330, 120, 35);
        btnBack.setBackground(new Color(0, 140, 200));
        btnBack.setForeground(Color.WHITE);
        add(btnBack);

        btnBack.addActionListener(e -> {
            dispose();
            new Ticket().setVisible(true);
        });
    }

    public static void main(String[] args) {
        new TicketView().setVisible(true);
    }


    TicketView(SystemColor info) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private TicketView() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}

